---Project Setup Notes (React + Vite + TailwindCSS)
Node.js >= 18.x
npm >= 9.x 
Vite is already configured in the project.
Tailwind CSS is already integrated.

# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev